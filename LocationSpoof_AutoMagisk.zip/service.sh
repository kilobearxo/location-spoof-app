#!/system/bin/sh
MODDIR=${0%/*}

# Function to set mock location using am broadcast or service
set_location() {
    LAT=$1
    LON=$2
    am startservice -a android.intent.action.MAIN -n com.mocklocation.service/.LocationService --es lat "$LAT" --es lon "$LON"
}

# App -> location map (sample)
declare -A app_locations
app_locations["com.draftkings"]="42.360081,-71.058884"  # Boston (DraftKings)
app_locations["com.fanduel"]="40.730610,-73.935242"     # New York (FanDuel)
app_locations["com.bankofamerica"]="34.052235,-118.243683" # LA (BoA)

while true; do
    current_app=$(dumpsys window windows | grep -E 'mCurrentFocus' | awk '{print $4}' | tr -d '}')
    if [[ -n "${app_locations[$current_app]}" ]]; then
        location=${app_locations[$current_app]}
        lat=$(echo $location | cut -d ',' -f1)
        lon=$(echo $location | cut -d ',' -f2)
        set_location "$lat" "$lon"
    fi
    sleep 5
done
