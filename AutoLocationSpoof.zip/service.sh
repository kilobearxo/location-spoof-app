#!/system/bin/sh
# Location switching daemon script
/data/adb/modules/AutoLocationSpoof/system/bin/autoswitch-location.sh &
