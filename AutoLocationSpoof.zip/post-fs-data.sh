#!/system/bin/sh
# Placeholder for post-fs-data script
